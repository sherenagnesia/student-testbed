#!/usr/bin/env bash
cd "$(dirname "$0")"
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Python belum terpasang (butuh 3.10+)."; exit 1; }
[ -d .venv ] || { echo "[1/3] Membuat lingkungan virtual..."; "$PY" -m venv .venv; }
source .venv/bin/activate
echo "[2/3] Memasang library..."
pip install --upgrade pip -q && pip install -r requirements.txt -q || exit 1
echo "[3/3] Menjalankan dashboard di http://localhost:8501"
streamlit run app.py --server.port 8501
