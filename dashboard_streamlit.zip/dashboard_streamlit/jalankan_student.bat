@echo off
cd /d "%~dp0"
title Student Performance Testbed
echo === 1. Cek Python ===
python --version
if errorlevel 1 goto trypy
set PY=python
goto install
:trypy
py --version
if errorlevel 1 goto nopy
set PY=py
goto install
:nopy
echo.
echo Python BELUM terpasang. Pasang dari https://www.python.org/downloads/
echo Centang "Add Python to PATH" saat instalasi, lalu jalankan file ini lagi.
pause
exit /b 1
:install
echo.
echo === 2. Memasang library (pertama kali agak lama) ===
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto gagal
echo.
echo === 3. Menjalankan Student Performance Testbed ===
echo Buka di browser: http://localhost:8502
%PY% -m streamlit run app_student.py --server.port 8502
pause
exit /b 0
:gagal
echo.
echo Gagal memasang library. Periksa koneksi internet, lalu coba lagi.
pause
exit /b 1
