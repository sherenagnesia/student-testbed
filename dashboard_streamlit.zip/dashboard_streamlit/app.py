"""
Dashboard Analisis Dataset Klasifikasi (Streamlit)
Alur: Upload CSV (sekali) -> Overview -> Data Understanding (EDA)
      -> Preprocessing -> Modeling -> Evaluation
Jalankan:  streamlit run app.py
"""
import io
import re
import time
import warnings
from collections import Counter

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

st.set_page_config(page_title="Dashboard Klasifikasi Dataset", page_icon="📊", layout="wide")

# ----------------------------------------------------------------------------
# STATE
# ----------------------------------------------------------------------------
ss = st.session_state
for key, val in {
    "locked": False,  # True = dataset sudah diunggah & dikunci
    "df": None,
    "target": None,
    "fname": None,
    "prep": None,
    "results": None,
}.items():
    ss.setdefault(key, val)


# ----------------------------------------------------------------------------
# HELPER
# ----------------------------------------------------------------------------
def load_csv(file) -> pd.DataFrame:
    raw = file.getvalue()
    last_err = None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(raw), sep=None, engine="python", encoding=enc)
        except Exception as e:  # noqa: BLE001
            last_err = e
    raise last_err


def candidate_class_cols(df: pd.DataFrame) -> list:
    """Kolom yang layak jadi atribut kelas: 2-30 nilai unik & tidak hampir unik per baris."""
    cands = []
    for c in df.columns:
        n = df[c].nunique(dropna=True)
        if 2 <= n <= 30 and n <= max(2, 0.5 * len(df)):
            cands.append(c)
    return cands


def split_cols(X: pd.DataFrame):
    num = X.select_dtypes(include=["number"]).columns.tolist()
    cat = [c for c in X.columns if c not in num]
    return num, cat


def _is_str(s: pd.Series) -> bool:
    """True untuk kolom teks (dtype object maupun string/str pada pandas 3)."""
    return s.dtype == object or pd.api.types.is_string_dtype(s)


def detect_drop_cols(d: pd.DataFrame, target: str) -> list:
    """Kolom konstan, ID-like, datetime, atau kardinalitas sangat tinggi."""
    drop = []
    n = len(d)
    for c in d.columns:
        if c == target:
            continue
        nun = d[c].nunique(dropna=True)
        if nun <= 1:
            drop.append(c)
        elif pd.api.types.is_datetime64_any_dtype(d[c]):
            drop.append(c)
        elif _is_str(d[c]) and nun == n:
            drop.append(c)
        elif _is_str(d[c]) and nun > 50 and nun / n > 0.5:
            drop.append(c)
        elif pd.api.types.is_integer_dtype(d[c]) and nun == n and (
            d[c].is_monotonic_increasing or d[c].is_monotonic_decreasing
        ):
            drop.append(c)
    return drop


def iqr_outlier_count(s: pd.Series) -> int:
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    return int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())


def _parse_dates(s: pd.Series) -> pd.Series:
    """Parse ke datetime (UTC) tanpa memunculkan warning; gagal parse -> NaT."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return pd.to_datetime(s, errors="coerce", utc=True)


@st.cache_data(show_spinner=False)
def detect_special_cols(df: pd.DataFrame, target: str):
    """Deteksi kolom tanggal dan kolom teks bebas (selain atribut kelas)."""
    date_cols, text_cols = [], []
    for c in df.columns:
        if c == target:
            continue
        s = df[c]
        if pd.api.types.is_datetime64_any_dtype(s):
            date_cols.append(c)
            continue
        if not (s.dtype == object or pd.api.types.is_string_dtype(s)):
            continue
        s = s.dropna().astype(str)
        if s.empty:
            continue
        sample = s.sample(min(len(s), 500), random_state=0)
        # kolom tanggal?
        date_pat = r"\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}"
        if sample.str.contains(date_pat).mean() >= 0.8 and sample.str.len().mean() <= 40:
            parsed = _parse_dates(sample)
            if parsed.notna().mean() >= 0.8 and parsed.nunique() > 1:
                date_cols.append(c)
                continue
        # kolom teks bebas?
        if (
            sample.str.len().mean() >= 25
            and sample.str.split().str.len().mean() >= 3
            and s.nunique() / len(s) > 0.3
        ):
            text_cols.append(c)
    return date_cols, text_cols


def add_date_features(d: pd.DataFrame, date_cols: list):
    """Ubah kolom tanggal menjadi fitur numerik (tahun, bulan, hari, hari-ke-minggu, jam)."""
    d = d.copy()
    done = []
    for c in date_cols:
        if c not in d.columns:
            continue
        try:
            dt = _parse_dates(d[c])
            d[f"{c}_tahun"] = dt.dt.year
            d[f"{c}_bulan"] = dt.dt.month
            d[f"{c}_hari"] = dt.dt.day
            d[f"{c}_hari_minggu"] = dt.dt.dayofweek
            if (dt.dt.hour.fillna(0) != 0).any():
                d[f"{c}_jam"] = dt.dt.hour
            d = d.drop(columns=[c])
            done.append(c)
        except Exception:  # noqa: BLE001
            continue
    return d, done


# ----------------------------------------------------------------------------
# TAHAP 0 : UPLOAD (hanya sekali)
# ----------------------------------------------------------------------------
def stage_upload():
    st.title("📊 Dashboard Analisis Dataset Klasifikasi")
    st.write(
        "Unggah dataset **CSV** untuk dianalisis. Unggah hanya bisa dilakukan **sekali**: "
        "setelah dataset dikunci, fitur unggah dimatikan dan seluruh hasil analisis "
        "melekat pada dataset tersebut."
    )
    file = st.file_uploader("Unggah file CSV", type=["csv"])
    if file is None:
        st.stop()

    try:
        df = load_csv(file)
    except Exception as e:  # noqa: BLE001
        st.error(f"File tidak dapat dibaca sebagai CSV: {e}")
        st.stop()

    df.columns = [str(c).strip() for c in df.columns]
    if df.shape[0] < 20 or df.shape[1] < 2:
        st.error("Dataset terlalu kecil (minimal 20 baris dan 2 kolom).")
        st.stop()

    st.subheader("Pratinjau data")
    st.dataframe(df.head(10))

    cands = candidate_class_cols(df)
    if not cands:
        st.error(
            "❌ Dataset ditolak (dibuang): tidak ditemukan atribut kelas. "
            "Atribut kelas harus kategorikal dengan 2–30 nilai unik."
        )
        st.stop()

    default_idx = len(cands) - 1 if df.columns[-1] in cands else 0
    if df.columns[-1] in cands:
        default_idx = cands.index(df.columns[-1])
    target = st.selectbox("Pilih atribut kelas (label)", cands, index=default_idx)
    st.caption("Distribusi kelas terpilih:")
    st.dataframe(df[target].value_counts(dropna=False).rename("jumlah").to_frame().T)

    st.warning("Setelah dikunci, dataset tidak bisa diganti dari dashboard ini.")
    if st.button("🔒 Kunci dataset & mulai analisis", type="primary"):
        d = df.dropna(subset=[target]).reset_index(drop=True)
        ss.df, ss.target, ss.fname, ss.locked = d, target, file.name, True
        ss.prep, ss.results = None, None
        st.rerun()
    st.stop()


# ----------------------------------------------------------------------------
# TAB 1 : OVERVIEW
# ----------------------------------------------------------------------------
def tab_overview(df, target):
    st.header("1. Overview Dataset")
    n_num = len(df.select_dtypes(include="number").columns)
    c = st.columns(5)
    c[0].metric("Jumlah baris", f"{df.shape[0]:,}")
    c[1].metric("Jumlah kolom", df.shape[1])
    c[2].metric("Fitur numerik", n_num - (1 if pd.api.types.is_numeric_dtype(df[target]) else 0))
    c[3].metric("Jumlah kelas", df[target].nunique())
    c[4].metric("Ukuran memori", f"{df.memory_usage(deep=True).sum() / 1024:.1f} KB")

    st.markdown(
        f"""
**Nama file:** `{ss.fname}`  
**Atribut kelas (target):** `{target}`  
**Tugas:** Klasifikasi {'biner' if df[target].nunique() == 2 else 'multikelas'}
dengan {df[target].nunique()} kelas: {', '.join(map(str, sorted(df[target].astype(str).unique())))}.
"""
    )

    left, right = st.columns([3, 2])
    with left:
        st.subheader("Kamus data (deskripsi atribut)")
        info = pd.DataFrame(
            {
                "Atribut": df.columns,
                "Tipe data": df.dtypes.astype(str).values,
                "Peran": ["Kelas (target)" if c == target else "Fitur" for c in df.columns],
                "Non-null": df.notna().sum().values,
                "Nilai unik": df.nunique().values,
                "Contoh nilai": [", ".join(map(str, df[c].dropna().unique()[:3])) for c in df.columns],
            }
        )
        st.dataframe(info, hide_index=True)
    with right:
        st.subheader("Distribusi kelas")
        vc = df[target].astype(str).value_counts().reset_index()
        vc.columns = [target, "jumlah"]
        fig = px.pie(vc, names=target, values="jumlah", hole=0.4)
        st.plotly_chart(fig)

    st.subheader("Cuplikan data")
    n = st.slider("Jumlah baris ditampilkan", 5, 50, 10)
    st.dataframe(df.head(n))


# ----------------------------------------------------------------------------
# TAB 2 : DATA UNDERSTANDING / EDA
# ----------------------------------------------------------------------------
def tab_eda(df, target):
    st.header("2. Data Understanding (EDA)")
    X = df.drop(columns=[target])
    num, cat = split_cols(X)
    date_cols, text_cols = detect_special_cols(df, target)
    cat = [c for c in cat if c not in text_cols and c not in date_cols]
    view = df.copy()
    view[target] = view[target].astype(str)

    # --- kualitas data
    st.subheader("2.1 Kualitas data")
    miss = df.isna().sum()
    c = st.columns(4)
    c[0].metric("Total missing value", int(miss.sum()))
    c[1].metric("Baris duplikat", int(df.duplicated().sum()))
    c[2].metric("Kolom konstan", int((df.nunique() <= 1).sum()))
    counts = df[target].value_counts()
    c[3].metric("Rasio imbalance (maks/min)", f"{counts.max() / counts.min():.2f}")

    mdf = pd.DataFrame({"Atribut": df.columns, "Missing": miss.values, "Persen (%)": (miss / len(df) * 100).round(2).values})
    mdf = mdf[mdf["Missing"] > 0]
    if mdf.empty:
        st.success("Tidak ada missing value.")
    else:
        st.plotly_chart(px.bar(mdf, x="Atribut", y="Persen (%)", title="Persentase missing value per atribut"))
        st.dataframe(mdf, hide_index=True)

    # --- statistik deskriptif
    st.subheader("2.2 Statistik deskriptif")
    if num:
        d = X[num].describe().T
        d["skewness"] = X[num].skew()
        d["kurtosis"] = X[num].kurt()
        d["outlier (IQR)"] = [iqr_outlier_count(X[c].dropna()) for c in num]
        st.markdown("**Fitur numerik**")
        st.dataframe(d.round(3))
    if cat:
        st.markdown("**Fitur kategorikal**")
        cd = pd.DataFrame(
            {
                "Atribut": cat,
                "Nilai unik": [X[c].nunique() for c in cat],
                "Modus": [X[c].mode().iloc[0] if not X[c].mode().empty else None for c in cat],
                "Frekuensi modus": [int(X[c].value_counts().iloc[0]) if X[c].notna().any() else 0 for c in cat],
            }
        )
        st.dataframe(cd, hide_index=True)

    # --- distribusi kelas
    st.subheader("2.3 Distribusi kelas")
    vc = view[target].value_counts().reset_index()
    vc.columns = [target, "jumlah"]
    vc["persen (%)"] = (vc["jumlah"] / vc["jumlah"].sum() * 100).round(2)
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(vc, x=target, y="jumlah", color=target, text="jumlah"))
    c2.dataframe(vc, hide_index=True)

    # --- univariat
    st.subheader("2.4 Analisis univariat & per kelas")
    if num:
        col = st.selectbox("Pilih fitur numerik", num, key="eda_num")
        c1, c2 = st.columns(2)
        c1.plotly_chart(px.histogram(view, x=col, color=target, marginal="box", barmode="overlay", opacity=0.7, title=f"Histogram {col}"))
        c2.plotly_chart(px.box(view, x=target, y=col, color=target, title=f"Boxplot {col} per kelas"))
    if cat:
        col = st.selectbox("Pilih fitur kategorikal", cat, key="eda_cat")
        top = view[col].value_counts().head(20).index
        sub = view[view[col].isin(top)]
        st.plotly_chart(px.histogram(sub, x=col, color=target, barmode="group", title=f"Sebaran {col} per kelas (maks 20 kategori teratas)"))

    # --- multivariat
    if len(num) >= 2:
        st.subheader("2.5 Korelasi & hubungan antar fitur")
        corr = X[num].corr()
        st.plotly_chart(px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r", zmin=-1, zmax=1, title="Matriks korelasi (Pearson)", aspect="auto"))

        pairs = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool)).stack().reset_index()
        pairs.columns = ["Fitur A", "Fitur B", "Korelasi"]
        pairs["|Korelasi|"] = pairs["Korelasi"].abs()
        st.markdown("**Pasangan fitur berkorelasi tertinggi**")
        st.dataframe(pairs.sort_values("|Korelasi|", ascending=False).head(10).drop(columns="|Korelasi|").round(3), hide_index=True)

        c1, c2, c3 = st.columns(3)
        xa = c1.selectbox("Sumbu X", num, index=0, key="sc_x")
        ya = c2.selectbox("Sumbu Y", num, index=min(1, len(num) - 1), key="sc_y")
        c3.write("")
        st.plotly_chart(px.scatter(view, x=xa, y=ya, color=target, opacity=0.7, title=f"{xa} vs {ya}"))

    # --- relevansi fitur terhadap kelas (ringkas)
    if num:
        st.subheader("2.6 Rata-rata fitur numerik per kelas")
        st.dataframe(view.groupby(target)[num].mean().round(3).T)

    st.subheader("2.7 Analisis teks & waktu")
    if not text_cols and not date_cols:
        st.caption("Tidak terdeteksi kolom teks bebas atau kolom tanggal pada dataset ini.")
    for tc in text_cols:
        st.markdown(f"**Kolom teks: `{tc}`**")
        txt = df[tc].fillna("").astype(str)
        tv = pd.DataFrame({"Panjang karakter": txt.str.len(), "Jumlah kata": txt.str.split().str.len(), target: view[target]})
        c1, c2 = st.columns(2)
        c1.plotly_chart(
            px.histogram(tv, x="Jumlah kata", color=target, barmode="overlay", opacity=0.7, title=f"Jumlah kata per kelas: {tc}"),
        )
        words = Counter(
            w for t in txt.sample(min(len(txt), 20000), random_state=0) for w in re.findall(r"\w+", t.lower()) if len(w) > 2
        )
        top = pd.DataFrame(words.most_common(15), columns=["Kata", "Frekuensi"])
        c2.plotly_chart(px.bar(top[::-1], x="Frekuensi", y="Kata", orientation="h", title="15 kata paling sering"))
        st.dataframe(tv.groupby(target)[["Panjang karakter", "Jumlah kata"]].mean().round(1))
    for dc in date_cols:
        dt = _parse_dates(df[dc])
        tmp = pd.DataFrame({"tanggal": dt.dt.floor("D"), "hari": dt.dt.day_name(), target: view[target]}).dropna(subset=["tanggal"])
        if tmp.empty:
            continue
        st.markdown(f"**Kolom tanggal: `{dc}`** ({tmp['tanggal'].min().date()} s.d. {tmp['tanggal'].max().date()})")
        daily = tmp.groupby(["tanggal", target]).size().reset_index(name="jumlah")
        c1, c2 = st.columns(2)
        c1.plotly_chart(px.line(daily, x="tanggal", y="jumlah", color=target, title=f"Jumlah data per hari: {dc}"))
        order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        c2.plotly_chart(
            px.histogram(tmp, x="hari", color=target, barmode="group", category_orders={"hari": order}, title="Sebaran per hari dalam seminggu"),
        )

    st.subheader("2.8 Temuan otomatis")
    notes = []
    if miss.sum() > 0:
        notes.append(f"Terdapat **{int(miss.sum())}** missing value pada {int((miss > 0).sum())} atribut → perlu imputasi.")
    if df.duplicated().sum() > 0:
        notes.append(f"Ada **{int(df.duplicated().sum())}** baris duplikat → pertimbangkan dihapus.")
    if counts.max() / counts.min() > 1.5:
        notes.append(f"Kelas **tidak seimbang** (rasio {counts.max() / counts.min():.2f}) → gunakan class_weight / metrik F1.")
    if num:
        sk = X[num].skew().abs()
        if (sk > 1).any():
            notes.append("Fitur dengan skewness tinggi: " + ", ".join(sk[sk > 1].index[:8]) + ".")
        oc = {c: iqr_outlier_count(X[c].dropna()) for c in num}
        oc = {k: v for k, v in oc.items() if v > 0}
        if oc:
            notes.append("Outlier terdeteksi (IQR) pada: " + ", ".join(f"{k} ({v})" for k, v in list(oc.items())[:8]) + ".")
    if cat:
        notes.append(f"Terdapat {len(cat)} fitur kategorikal → perlu encoding.")
    for n in notes or ["Data relatif bersih."]:
        st.markdown(f"- {n}")


# ----------------------------------------------------------------------------
# TAB 3 : PREPROCESSING
# ----------------------------------------------------------------------------
def run_preprocessing(df, target, o):
    log = []
    d = df.copy()
    n0 = len(d)

    if o["dup"]:
        d = d.drop_duplicates()
        log.append(f"Hapus duplikat: {n0 - len(d)} baris dibuang.")

    if o.get("date") and o.get("date_cols"):
        d, date_done = add_date_features(d, o["date_cols"])
        log.append(f"Fitur tanggal diekstrak (tahun, bulan, hari, hari-ke-minggu, jam) dari: {date_done if date_done else 'tidak ada'}.")

    text_cols = [c for c in o.get("text_cols", []) if c in d.columns] if o.get("tfidf") else []

    dropped = []
    if o["drop_id"]:
        dropped = [c for c in detect_drop_cols(d, target) if c not in text_cols]
        d = d.drop(columns=dropped)
        log.append(f"Kolom dibuang (konstan/ID/kardinalitas tinggi/datetime): {dropped if dropped else 'tidak ada'}.")

    vc = d[target].astype(str).value_counts()
    rare = vc[vc < 2].index.tolist()
    if rare:
        d = d[~d[target].astype(str).isin(rare)]
        log.append(f"Kelas dengan <2 sampel dibuang: {rare}.")

    X = d.drop(columns=[target]).copy()
    for c in X.select_dtypes(include="bool").columns:
        X[c] = X[c].astype(int)
    for c in text_cols:
        X[c] = X[c].fillna("").astype(str)
    le = LabelEncoder()
    y = le.fit_transform(d[target].astype(str))
    log.append(f"Label encoding target: {dict(zip(le.classes_, range(len(le.classes_))))}.")

    try:
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=o["test"], random_state=o["seed"], stratify=y if o["stratify"] else None
        )
    except ValueError:
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=o["test"], random_state=o["seed"])
        log.append("Stratifikasi gagal (sampel kelas terlalu sedikit) → split acak biasa.")
    log.append(f"Split data: train {len(X_tr)} baris, test {len(X_te)} baris (test_size={o['test']}).")

    num, cat = split_cols(X_tr.drop(columns=text_cols))

    if o["outlier"] == "Clipping IQR" and num:
        for c in num:
            q1, q3 = X_tr[c].quantile(0.25), X_tr[c].quantile(0.75)
            iqr = q3 - q1
            lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            X_tr[c] = X_tr[c].clip(lo, hi)
            X_te[c] = X_te[c].clip(lo, hi)
        log.append("Outlier di-clip dengan batas IQR (dihitung dari data train).")

    scalers = {"StandardScaler": StandardScaler, "MinMaxScaler": MinMaxScaler}
    num_steps = [("imp", SimpleImputer(strategy=o["num_imp"]))]
    if o["scaler"] in scalers:
        num_steps.append(("sc", scalers[o["scaler"]]()))
    transformers = []
    if num:
        transformers.append(("num", Pipeline(num_steps), num))
    if cat:
        transformers.append(
            (
                "cat",
                Pipeline(
                    [
                        ("imp", SimpleImputer(strategy="most_frequent")),
                        ("oh", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
                    ]
                ),
                cat,
            )
        )
    for i, tc in enumerate(text_cols):
        char_mode = o["tfidf_an"] == "char_wb"
        transformers.append(
            (
                f"tfidf_{i}",
                TfidfVectorizer(
                    max_features=o["tfidf_max"],
                    analyzer=o["tfidf_an"],
                    ngram_range=(2, 4) if char_mode else (1, 1),
                    sublinear_tf=True,
                    min_df=1,
                ),
                tc,  # string (bukan list) -> input 1D untuk vectorizer
            )
        )
    if not transformers:
        raise ValueError("Tidak ada fitur tersisa setelah preprocessing.")
    ct = ColumnTransformer(transformers, sparse_threshold=0)
    A_tr = ct.fit_transform(X_tr)
    A_te = ct.transform(X_te)
    names = []
    for n in ct.get_feature_names_out():
        m = re.match(r"tfidf_(\d+)__(.*)", n)
        names.append(f"{text_cols[int(m.group(1))]}~{m.group(2)}" if m else n.split("__", 1)[-1])
    log.append(f"Imputasi numerik ({o['num_imp']}), kategorikal (modus), scaling: {o['scaler']}, one-hot encoding {len(cat)} fitur kategorikal.")
    if text_cols:
        log.append(f"TF-IDF ({'karakter n-gram 2–4' if o['tfidf_an'] == 'char_wb' else 'kata'}) pada kolom teks {text_cols}, maks {o['tfidf_max']} fitur per kolom.")

    return {
        "X_train": pd.DataFrame(A_tr, columns=names),
        "X_test": pd.DataFrame(A_te, columns=names),
        "y_train": y_tr,
        "y_test": y_te,
        "le": le,
        "features": names,
        "log": log,
        "dropped": dropped,
        "shape_before": df.shape,
        "shape_after": (len(d), len(names)),
        "missing_before": int(df.isna().sum().sum()),
    }


def tab_prep(df, target):
    st.header("3. Data Preprocessing")
    date_det, text_det = detect_special_cols(df, target)
    str_cols = [
        c for c in df.columns
        if c != target and (df[c].dtype == object or pd.api.types.is_string_dtype(df[c]) or pd.api.types.is_datetime64_any_dtype(df[c]))
    ]
    with st.form("prep_form"):
        c1, c2, c3 = st.columns(3)
        dup = c1.checkbox("Hapus baris duplikat", True)
        drop_id = c1.checkbox("Buang kolom konstan / ID / kardinalitas tinggi", True)
        num_imp = c2.selectbox("Imputasi numerik", ["median", "mean"])
        scaler = c2.selectbox("Scaling", ["StandardScaler", "MinMaxScaler", "Tanpa scaling"])
        outlier = c3.selectbox("Penanganan outlier", ["Tidak ada", "Clipping IQR"])
        test = c3.slider("Proporsi data uji", 0.1, 0.5, 0.2, 0.05)
        stratify = c1.checkbox("Stratified split", True)
        seed = c2.number_input("Random state", 0, 9999, 42)
        st.markdown("**Fitur tanggal & teks**")
        d1, d2 = st.columns(2)
        use_date = d1.checkbox("Ekstrak fitur dari kolom tanggal (tahun, bulan, hari, hari-ke-minggu, jam)", bool(date_det), disabled=not str_cols)
        sel_date = d1.multiselect("Kolom tanggal", str_cols, default=date_det, disabled=not str_cols)
        use_tfidf = d2.checkbox("Ubah kolom teks menjadi fitur TF-IDF", bool(text_det), disabled=not str_cols)
        sel_text = d2.multiselect("Kolom teks", str_cols, default=text_det, disabled=not str_cols)
        tfidf_max = d2.slider("Maks fitur TF-IDF per kolom", 50, 1500, 300, 50)
        tfidf_an = d2.selectbox(
            "Tokenisasi TF-IDF",
            ["word", "char_wb"],
            format_func=lambda v: "Kata (bahasa yang dipisah spasi)" if v == "word" else "Karakter n-gram (multibahasa / Mandarin / Jepang / Thai)",
        )
        go_btn = st.form_submit_button("▶ Jalankan preprocessing", type="primary")

    if go_btn:
        try:
            ss.prep = run_preprocessing(
                df, target, dict(
                    dup=dup, drop_id=drop_id, num_imp=num_imp, scaler=scaler, outlier=outlier, test=test, stratify=stratify, seed=int(seed),
                    date=use_date, date_cols=sel_date, tfidf=use_tfidf, text_cols=sel_text, tfidf_max=tfidf_max, tfidf_an=tfidf_an,
                )
            )
            ss.results = None  # model lama tidak berlaku lagi
        except Exception as e:  # noqa: BLE001
            st.error(f"Preprocessing gagal: {e}")
            return

    p = ss.prep
    if p is None:
        st.info("Atur opsi lalu klik **Jalankan preprocessing**.")
        return

    st.success("Preprocessing selesai.")
    c = st.columns(4)
    c[0].metric("Baris sebelum → sesudah", f"{p['shape_before'][0]} → {p['shape_after'][0]}")
    c[1].metric("Kolom sebelum → fitur sesudah", f"{p['shape_before'][1] - 1} → {p['shape_after'][1]}")
    c[2].metric("Missing sebelum → sesudah", f"{p['missing_before']} → 0")
    c[3].metric("Train / Test", f"{len(p['y_train'])} / {len(p['y_test'])}")

    st.subheader("Langkah yang dilakukan")
    for line in p["log"]:
        st.markdown(f"- {line}")

    st.subheader("Data latih hasil preprocessing")
    st.dataframe(p["X_train"].head(20))

    tr = pd.Series(p["le"].inverse_transform(p["y_train"])).value_counts()
    te = pd.Series(p["le"].inverse_transform(p["y_test"])).value_counts()
    dist = pd.DataFrame({"Train": tr, "Test": te}).fillna(0).astype(int).reset_index().rename(columns={"index": "Kelas"})
    dist = dist.rename(columns={dist.columns[0]: "Kelas"})
    st.plotly_chart(px.bar(dist.melt(id_vars="Kelas", var_name="Set", value_name="jumlah"), x="Kelas", y="jumlah", color="Set", barmode="group", title="Distribusi kelas pada train vs test"))


# ----------------------------------------------------------------------------
# TAB 4 : MODELING
# ----------------------------------------------------------------------------
def build_model(name, prm):
    cw = "balanced" if prm["balanced"] else None
    if name == "Logistic Regression":
        return LogisticRegression(max_iter=2000, C=prm["lr_c"], class_weight=cw)
    if name == "K-Nearest Neighbors":
        return KNeighborsClassifier(n_neighbors=prm["knn_k"])
    if name == "Decision Tree":
        return DecisionTreeClassifier(max_depth=prm["dt_depth"], class_weight=cw, random_state=42)
    if name == "Random Forest":
        return RandomForestClassifier(n_estimators=prm["rf_n"], class_weight=cw, random_state=42, n_jobs=-1)
    if name == "Naive Bayes (Gaussian)":
        return GaussianNB()
    if name == "SVM (RBF)":
        return SVC(C=prm["svm_c"], probability=True, class_weight=cw, random_state=42)
    raise ValueError(name)


ALL_MODELS = ["Logistic Regression", "K-Nearest Neighbors", "Decision Tree", "Random Forest", "Naive Bayes (Gaussian)", "SVM (RBF)"]


def tab_model():
    st.header("4. Modeling")
    p = ss.prep
    if p is None:
        st.info("Jalankan preprocessing terlebih dahulu di tab **Preprocessing**.")
        return

    chosen = st.multiselect("Pilih model (minimal 2)", ALL_MODELS, default=["Logistic Regression", "Random Forest", "K-Nearest Neighbors"])
    with st.expander("Hyperparameter"):
        c1, c2, c3 = st.columns(3)
        prm = {
            "lr_c": c1.number_input("Logistic Regression: C", 0.01, 100.0, 1.0),
            "knn_k": c1.slider("KNN: jumlah tetangga (k)", 1, 25, 5),
            "dt_depth": c2.slider("Decision Tree: max depth", 1, 30, 6),
            "rf_n": c2.slider("Random Forest: jumlah pohon", 20, 500, 150, 10),
            "svm_c": c3.number_input("SVM: C", 0.01, 100.0, 1.0),
            "balanced": c3.checkbox("class_weight = balanced (jika didukung)", False),
        }
    cv_on = st.checkbox("Hitung cross-validation pada data latih", True)

    if st.button("🚀 Latih model", type="primary"):
        if len(chosen) < 2:
            st.error("Pilih minimal 2 model.")
            return
        Xtr, Xte, ytr, yte = p["X_train"], p["X_test"], p["y_train"], p["y_test"]
        min_cls = int(np.bincount(ytr).min())
        folds = min(5, min_cls)
        res = {}
        bar = st.progress(0.0)
        for i, name in enumerate(chosen):
            m = build_model(name, prm)
            t0 = time.time()
            m.fit(Xtr, ytr)
            fit_t = time.time() - t0
            pred = m.predict(Xte)
            proba = m.predict_proba(Xte) if hasattr(m, "predict_proba") else None
            cv = None
            if cv_on and folds >= 2:
                try:
                    cv = cross_val_score(build_model(name, prm), Xtr, ytr, cv=folds, scoring="f1_weighted")
                except Exception:  # noqa: BLE001
                    cv = None
            res[name] = {"model": m, "pred": pred, "proba": proba, "time": fit_t, "cv": cv}
            bar.progress((i + 1) / len(chosen))
        ss.results = res
        st.success(f"{len(chosen)} model berhasil dilatih. Lihat tab **Evaluation**.")

    if ss.results:
        st.subheader("Model yang sudah dilatih")
        st.dataframe(
            pd.DataFrame(
                {
                    "Model": list(ss.results.keys()),
                    "Waktu latih (detik)": [round(v["time"], 3) for v in ss.results.values()],
                    "CV F1 (rata-rata)": [round(v["cv"].mean(), 4) if v["cv"] is not None else None for v in ss.results.values()],
                    "CV F1 (std)": [round(v["cv"].std(), 4) if v["cv"] is not None else None for v in ss.results.values()],
                }
            ),
            hide_index=True,
        )


# ----------------------------------------------------------------------------
# TAB 5 : EVALUATION
# ----------------------------------------------------------------------------
def tab_eval():
    st.header("5. Evaluation")
    p, res = ss.prep, ss.results
    if p is None or not res:
        st.info("Latih minimal 2 model di tab **Modeling** terlebih dahulu.")
        return

    yte = p["y_test"]
    classes = p["le"].classes_
    rows = []
    for name, r in res.items():
        pred, proba = r["pred"], r["proba"]
        auc = np.nan
        if proba is not None:
            try:
                auc = roc_auc_score(yte, proba[:, 1]) if len(classes) == 2 else roc_auc_score(yte, proba, multi_class="ovr", average="weighted", labels=range(len(classes)))
            except Exception:  # noqa: BLE001
                pass
        rows.append(
            {
                "Model": name,
                "Accuracy": accuracy_score(yte, pred),
                "Precision": precision_score(yte, pred, average="weighted", zero_division=0),
                "Recall": recall_score(yte, pred, average="weighted", zero_division=0),
                "F1 (weighted)": f1_score(yte, pred, average="weighted", zero_division=0),
                "F1 (macro)": f1_score(yte, pred, average="macro", zero_division=0),
                "ROC-AUC": auc,
            }
        )
    mdf = pd.DataFrame(rows).set_index("Model")

    st.subheader("5.1 Perbandingan metrik")
    st.dataframe(mdf.round(4).style.highlight_max(axis=0, color="#b7e4c7"))
    long = mdf.drop(columns=["ROC-AUC"]).reset_index().melt(id_vars="Model", var_name="Metrik", value_name="Skor")
    st.plotly_chart(px.bar(long, x="Metrik", y="Skor", color="Model", barmode="group", range_y=[0, 1.05]))
    st.download_button("⬇ Unduh tabel evaluasi (CSV)", mdf.round(4).to_csv().encode("utf-8"), "hasil_evaluasi.csv", "text/csv")

    best = mdf["F1 (weighted)"].idxmax()
    st.success(f"🏆 Model terbaik berdasarkan F1 (weighted): **{best}** ({mdf.loc[best, 'F1 (weighted)']:.4f}); akurasi {mdf.loc[best, 'Accuracy']:.4f}.")

    st.subheader("5.2 Detail per model")
    pick = st.selectbox("Pilih model", list(res.keys()), index=list(res.keys()).index(best))
    r = res[pick]
    c1, c2 = st.columns(2)
    cm = confusion_matrix(yte, r["pred"], labels=range(len(classes)))
    c1.plotly_chart(
        px.imshow(cm, x=[str(c) for c in classes], y=[str(c) for c in classes], text_auto=True, color_continuous_scale="Blues", labels=dict(x="Prediksi", y="Aktual", color="Jumlah"), title=f"Confusion matrix: {pick}"),
    )
    rep = classification_report(yte, r["pred"], labels=range(len(classes)), target_names=[str(c) for c in classes], output_dict=True, zero_division=0)
    c2.markdown("**Classification report**")
    c2.dataframe(pd.DataFrame(rep).T.round(3))
    if r["cv"] is not None:
        c2.caption(f"Cross-validation F1: {r['cv'].mean():.4f} ± {r['cv'].std():.4f}")

    # ROC (biner)
    if len(classes) == 2:
        st.subheader("5.3 Kurva ROC")
        fig = go.Figure()
        for name, rr in res.items():
            if rr["proba"] is not None:
                fpr, tpr, _ = roc_curve(yte, rr["proba"][:, 1])
                fig.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines", name=f"{name} (AUC={mdf.loc[name, 'ROC-AUC']:.3f})"))
        fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash", color="gray"), name="Acak"))
        fig.update_layout(xaxis_title="False Positive Rate", yaxis_title="True Positive Rate")
        st.plotly_chart(fig)

    # Feature importance
    m = r["model"]
    imp = None
    if hasattr(m, "feature_importances_"):
        imp = m.feature_importances_
    elif hasattr(m, "coef_"):
        imp = np.abs(m.coef_).mean(axis=0)
    if imp is not None:
        st.subheader("5.4 Fitur paling berpengaruh")
        fi = pd.DataFrame({"Fitur": p["features"], "Pentingnya": imp}).sort_values("Pentingnya", ascending=False).head(15)
        st.plotly_chart(px.bar(fi[::-1], x="Pentingnya", y="Fitur", orientation="h", title=f"Top 15 fitur: {pick}"))

    st.subheader("5.5 Kesimpulan")
    worst = mdf["F1 (weighted)"].idxmin()
    st.markdown(
        f"- Dari {len(res)} model, **{best}** memberi F1 tertinggi ({mdf.loc[best, 'F1 (weighted)']:.4f}), sedangkan **{worst}** terendah ({mdf.loc[worst, 'F1 (weighted)']:.4f}).\n"
        f"- Selisih F1 terbaik–terendah: {mdf['F1 (weighted)'].max() - mdf['F1 (weighted)'].min():.4f}.\n"
        "- Periksa confusion matrix untuk melihat kelas yang paling sering salah diprediksi, terutama bila kelas tidak seimbang."
    )


# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------
if not ss.locked:
    stage_upload()

df, target = ss.df, ss.target

with st.sidebar:
    st.header("📁 Dataset")
    st.success("Dataset terkunci 🔒")
    st.write(f"**File:** {ss.fname}")
    st.write(f"**Baris × kolom:** {df.shape[0]} × {df.shape[1]}")
    st.write(f"**Atribut kelas:** {target}")
    st.caption("Fitur unggah dinonaktifkan. Untuk memakai dataset lain, muat ulang (refresh) halaman.")

st.title("📊 Dashboard Analisis Dataset Klasifikasi")
t1, t2, t3, t4, t5 = st.tabs(["Overview", "Data Understanding (EDA)", "Preprocessing", "Modeling", "Evaluation"])
with t1:
    tab_overview(df, target)
with t2:
    tab_eda(df, target)
with t3:
    tab_prep(df, target)
with t4:
    tab_model()
with t5:
    tab_eval()
